<body onload="document.valid_id_form.magic_field.focus()" style="background: yellow">
	<h1 style="padding-top: 6em;">Please Perform A Visual ID Check</h1>

	<form name="valid_id_form" id="valid_id_form" action="check_card.php" method="get" accept-charset="utf-8">
		<input type="text" name="magic_field" value="" id="magic_field">
		<p><input id="submit_id" name="submit_id" type="submit" value="Valid?"></p>
	</form>
	
	
	<body onload="setTimeout('redirect()', 1500)" style="background: green">
		<h1 style="padding-top: 6em">Good to Go!</h1>
	
	
	
		<body style="background: red">
			<h1 style="padding-top: 6em">Entry Denied</h1>
			<h2>Please Seek Advice</h2>
			<a href="index.php">Back to Start...</a>