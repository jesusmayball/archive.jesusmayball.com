<?

//$cv = mysqli_connect("localhost","mayball","th4sPuc3fu");
$cv = mysqli_connect("localhost", "mayball_admin", "tuchU6EDen");
mysqli_select_db($cv,"mayball");


?>