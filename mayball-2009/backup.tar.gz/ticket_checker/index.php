<link rel="stylesheet" href="master.css" type="text/css" media="screen" charset="utf-8">
<body onload="document.check_ticket_form.ticket_id.focus()">
	<h1>Jesus May Ball 2009</h1>
	<h2>Ticketing System</h2>
<form name="check_ticket_form" id="check_ticket_form" action="check_ticket.php" method="get" accept-charset="utf-8">
	
<input type="text" name="ticket_id" value="" id="ticket_id">
	<p><input type="submit" value="Check Ticket &rarr;"></p>
</form>
</body>