<link rel="stylesheet" href="master.css" type="text/css" media="screen" charset="utf-8">
<script type="text/javascript">
function redirect(){
	window.location = "index.php"
}
</script>

<?php
$magic_deny_card_id = "DENY";
$magic_admit_card_id = "ADMIT";

include "database_connect.php";

$ticket_code = mysqli_real_escape_string($cv, $_GET["ticket_id"]);
$card_code = mysqli_real_escape_string($cv, $_GET["card_id"]);

$q = mysqli_real_query($cv, "SELECT people.*, ticket_types.* FROM people INNER JOIN tickets ON people.person_id=tickets.person_id INNER JOIN ticket_types ON tickets.ticket_type_id = ticket_types.ticket_type_id WHERE tickets.hash_code = '$ticket_code' AND people.uni_barcode = '$card_code'");

if($result = mysqli_use_result($cv)) {
	$row = mysqli_fetch_assoc($result);
	if($row != null || $_GET["magic_field"] == $magic_admit_card_id) {
		//let us in!
		mysqli_free_result($result);
		$q2 = mysqli_query($cv, "UPDATE tickets SET entered_at = NOW() WHERE hash_code ='$ticket_code';");
		echo mysqli_error($cv);
		?>
		<body onload="setTimeout('redirect()', 1500)" style="background: green">
			<h1 style="padding-top: 6em">Good to Go!</h1>
		</body>
		<?
	}
	else if($_GET["magic_field"] == $magic_deny_card_id) {
		?>
		<body onload="setTimeout('redirect()', 5000)" style="background: red">
			<h1 style="padding-top: 6em">Entry Denied</h1>
			<h2>Please Seek Advice</h2>
			<a href="index.php">Back to Start...</a>
		</body>
		<?
	}
	else {
		//missing data!
		?>
		<body onload="document.valid_id_form.magic_field.focus()" style="background: yellow">
			<h1 style="padding-top: 3em;"><?= $_GET["full_name"] ?></h1>
			<h2>Please Perform A Visual ID Check</h2>
			<form name="valid_id_form" id="valid_id_form" action="check_card.php" method="get" accept-charset="utf-8">
				<input type="text" name="magic_field" value="" id="magic_field">
				<input type="hidden" name="ticket_id" value="<?= $_GET["ticket_id"] ?>" />
				<input type="hidden" name="full_name" id="full_name" value="<?= $_GET["full_name"] ?>" />
				<p><input id="submit_id" name="submit_id" type="submit" value="Valid?"></p>
			</form>
		</body>
		<?php
	}
}

mysqli_close($cv);


?>
