<link rel="stylesheet" href="master.css" type="text/css" media="screen" charset="utf-8">
<script type="text/javascript">
function redirect(){
        window.location = "index.php"
}
</script>
<?php

include "database_connect.php";

$ticket_code = mysqli_real_escape_string($cv, $_GET["ticket_id"]);
$q = mysqli_real_query($cv, "SELECT people.*, ticket_types.* FROM people INNER JOIN tickets ON people.person_id=tickets.person_id INNER JOIN ticket_types ON tickets.ticket_type_id = ticket_types.ticket_type_id WHERE tickets.hash_code = '$ticket_code' AND tickets.entered_at = 0 AND tickets.valid = 1");



if($result = mysqli_use_result($cv)) {
	$row = mysqli_fetch_assoc($result);
	if($row == null) {
		//missing ticket data!
		?>
		<body onload="setTimeout('redirect()', 5000)" style="background: red">
			<h1 style="padding-top: 6em">Entry Denied</h1>
			<h2>Ticket Number Does Not Exist</h2>
			<a href="index.php">Back to Start...</a>
		</body>
		<?
	}
	else {
		$name = $row["first_name"] . " " . $row["last_name"];
		$college = $row["college"];
		$ticket_type = $row["ticket_type"];
		$ticket_price = $row["price"];
		?>
<body onload="document.check_card_form.card_id.focus()">
	<h1>Jesus May Ball 2009</h1>
	<h2>Ticketing System</h2>
<p><?= $name ?><br /><?= $college?><br /><?= $ticket_type?><br /><?= "£" . $ticket_price?></p>

<form name="check_card_form" id="check_card_id" action="check_card.php" method="get" accept-charset="utf-8">
	<input type="hidden" name="ticket_id" id="ticket_id" value="<?= $_GET["ticket_id"] ?>" />
	<input type="hidden" name="full_name" id="full_name" value="<?= $name ?>" />
<input type="text" name="card_id" value="" id="card_id">
	<p><input id="submit_id" name="submit_id" type="submit" value="Submit ID &rarr;">&nbsp;<input id="no_id" name="no_id" type="submit" value="No Uni Card?"></p>
</form>
<?
	}
   mysqli_free_result($result);
}

mysqli_close($cv);

?>
