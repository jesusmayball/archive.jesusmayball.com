<?php


function ticket_hash_code($id) {
	$hash = hash("sha512", $id + time());
	$start = rand(0,122);
	return substr(strtoupper($hash),$start, 5);
}

function cheque_hash_code($id) {
	$hash = hash("sha512", $id + time());
	$start = rand(0,122);
	return substr(strtoupper($hash),$start, 5);	
}

?>