<?php
ini_set("session.cookie_domain", "jesusmayball.com");
ini_set("session.name", "JESUSMAYBALL_SESSION");
session_start();
?>
<html>
<head>
<title>Jesus May Ball Ticketing System</title>
<script src="../jquery.js" type="text/javascript"></script>
<?php


if($_GET["step"] == 1) {
	include "../ldap_client.php";
	$identity = getLookupInfo(
	$_SERVER["REMOTE_USER"]
	//$_GET["user"]
	);
?>
	
<script type="text/javascript">

function stripslashes(str) { 
   	return str.replace(/\\/g, '');
}

function showDepartmentBox(e) {
	if($("#college_field").val() == "None") {
	$("#no_college").html("<label for=\"department_field\">or Department: </label><input type=\"text\" id=\"department_field\" name=\"department\" value=\"<?= $identity["college"] ?>\" />");
	}
	else {
	$("#no_college").html("");
	}
}

$("document").ready(function() {
	$("#college_field").bind("change", showDepartmentBox);
	showDepartmentBox();
	data = <?= json_encode($_SESSION["principal"]) ?>;
	if(data != "undefined") {
			$("#title_field").val(data.title);
			$("#first_name_field").val(stripslashes(data.first_name));
			$("#last_name_field").val(stripslashes(data.last_name));
			$("#gender_field").val(data.gender);
			$("#college_field").val(stripslashes(data.college));
			$("#phone_field").val(data.phone);
			$("#barcode_field").val(data.barcode);
	}
});


</script>
</head>
<body>
	
	<h2>Main Applicant's Details</h2>
	<form method="post" action="personal_buy.php?step=2">
	<label for="title_field">Title*:</label>
	<select id="title_field" name="title">
		<option value="Mr" <? if($identity["title"] == "Mr") echo "selected=\"selected\""; ?>>Mr</option>
		<option value="Mrs" <? if($identity["title"] == "Mrs") echo "selected=\"selected\""; ?>>Mrs</option>
		<option value="Miss" <? if($identity["title"] == "Miss") echo "selected=\"selected\""; ?>>Miss</option>
		<option value="Ms" <? if($identity["title"] == "Ms") echo "selected=\"selected\""; ?>>Ms</option>
		<option value="Dr" <? if($identity["title"] == "Dr") echo "selected=\"selected\""; ?>>Dr</option>
		<option value="Prof" <? if($identity["title"] == "Prof") echo "selected=\"selected\""; ?>>Prof</option>
		<option value="Sir" <? if($identity["title"] == "Sir") echo "selected=\"selected\""; ?>>Sir</option>
	</select>
	<br />
	
	<label for="first_name_field">First Name*:</label>
	<input type="text" id="first_name_field" name="first_name" value="<?= $identity["first_name"] ?>" /><br />
	
	<label for="first_name_field">Last Name*:</label>
	<input type="text" id="last_name_field" name="last_name" value="<?= $identity["last_name"] ?>" /><br />
	
	<label for="gender_field">Gender*:</label>
	<select id="gender_field" name="gender">
	<option value="Male">Male</option>
	<option value="Female">Female</option>
	</select>
	<br />

	<label for="college_field">College*:</label>
	<select id="college_field" name="college">
		<option value="None">None</option>
		<option value="Christ's College" <? if($identity["college"] == "Christ's College") echo "selected=\"selected\""; ?>>Christ's College</option>
		<option value="Churchill College" <? if($identity["college"] == "Churchill College") echo "selected=\"selected\""; ?>>Churchill College</option>
		<option value="Clare College" <? if($identity["college"] == "Clare College") echo "selected=\"selected\""; ?>>Clare College</option>
		<option value="Clare Hall" <? if($identity["college"] == "Clare Hall") echo "selected=\"selected\""; ?>>Clare Hall</option>
		<option value="Corpus Christi College" <? if($identity["college"] == "Corpus Christi College") echo "selected=\"selected\""; ?>>Corpus Christi College</option>
		<option value="Darwin College" <? if($identity["college"] == "Darwin College") echo "selected=\"selected\""; ?>>Darwin College</option>
		<option value="Downing College" <? if($identity["college"] == "Downing College") echo "selected=\"selected\""; ?>>Downing College</option>
		<option value="Emmanuel College" <? if($identity["college"] == "Emmanuel College") echo "selected=\"selected\""; ?>>Emmanuel College</option>
		<option value="Fitzwilliam College" <? if($identity["college"] == "Fitzwilliam College") echo "selected=\"selected\""; ?>>Fitzwilliam College</option>
		<option value="Girton College" <? if($identity["college"] == "Girton College") echo "selected=\"selected\""; ?>>Girton College</option>
		<option value="Gonville and Caius College" <? if($identity["college"] == "Gonville and Caius College") echo "selected=\"selected\""; ?>>Gonville and Caius College</option>
		<option value="Homerton College" <? if($identity["college"] == "Homerton College") echo "selected=\"selected\""; ?>>Homerton College</option>
		<option value="Hughes Hall" <? if($identity["college"] == "Hughes Hall") echo "selected=\"selected\""; ?>>Hughes Hall</option>
		<option value="Jesus College" <? if($identity["college"] == "Jesus College") echo "selected=\"selected\""; ?>>Jesus College</option>
		<option value="King's College" <? if($identity["college"] == "King's College") echo "selected=\"selected\""; ?>>King's College</option>
		<option value="Lucy Cavendish College" <? if($identity["college"] == "Lucy Cavendish College") echo "selected=\"selected\""; ?>>Lucy Cavendish College</option>
		<option value="Magdalene College" <? if($identity["college"] == "Magdalene College") echo "selected=\"selected\""; ?>>Magdalene College</option>
		<option value="New Hall" <? if($identity["college"] == "New Hall") echo "selected=\"selected\""; ?>>New Hall (Murray Edwards)</option>
		<option value="Newnham College" <? if($identity["college"] == "Newnham College") echo "selected=\"selected\""; ?>>Newnham College</option>
		<option value="Pembroke College" <? if($identity["college"] == "Pembroke College") echo "selected=\"selected\""; ?>>Pembroke College</option>
		<option value="Peterhouse" <? if($identity["college"] == "Peterhouse") echo "selected=\"selected\""; ?>>Peterhouse</option>
		<option value="Queens' College" <? if($identity["college"] == "Queens' College") echo "selected=\"selected\""; ?>>Queens' College</option>
		<option value="Robinson College" <? if($identity["college"] == "Robinson College") echo "selected=\"selected\""; ?>>Robinson College</option>
		<option value="St Catharine's College" <? if($identity["college"] == "St Catharine's College") echo "selected=\"selected\""; ?>>St Catharine's College</option>
		<option value="St Edmund's College" <? if($identity["college"] == "St Edmund's College") echo "selected=\"selected\""; ?>>St Edmund's College</option>
		<option value="St John's College" <? if($identity["college"] == "St John's College") echo "selected=\"selected\""; ?>>St John's College</option>
		<option value="Selwyn College" <? if($identity["college"] == "Selwyn College") echo "selected=\"selected\""; ?>>Selwyn College</option>
		<option value="Sidney Sussex College" <? if($identity["college"] == "Sidney Sussex College") echo "selected=\"selected\""; ?>>Sidney Sussex College</option>
		<option value="Trinity College" <? if($identity["college"] == "Trinity College") echo "selected=\"selected\""; ?>>Trinity College</option>
		<option value="Trinity Hall" <? if($identity["college"] == "Trinity Hall") echo "selected=\"selected\""; ?>>Trinity Hall</option>
		<option value="Wolfson College" <? if($identity["college"] == "Wolfson College") echo "selected=\"selected\""; ?>>Wolfson College</option>
	</select> <span id="no_college"></span><br />
	
	<label for="phone_field">Phone*:</label>
	<input type="text" id="phone_field" name="phone" value="" /><br />
		
	<label for="crsid_field">CRSID*:</label>
	<input type="text" id="crsid_field" name="crsid" value="<?= $_SERVER["REMOTE_USER"] ?>" readonly="readonly" /><br />
	
	<label for="barcode_field">Barcode*:</label>
	<input type="text" id="barcode_field" name="barcode" /><br />
	
	<input type="submit" value="Next Step &rarr;" name="submit" /><br />
	
	</form>
	
	
<?php
}


if($_GET["step"] == 2) {

	include "../database_connect.php";

	if($_POST["title"]) {
		$_SESSION["principal"]["title"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z+]/', "", $_POST["title"])));
		$_SESSION["principal"]["first_name"] = mysqli_real_escape_string($cv, stripslashes(preg_replace('/[^A-Za-z\'\.\s+]/', "", $_POST["first_name"])));
		$_SESSION["principal"]["last_name"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z\'\.\s+]/', "", $_POST["last_name"])));
		$_SESSION["principal"]["gender"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z+]/', "", $_POST["gender"])));
		$_SESSION["principal"]["college"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z\'\s+]/', "", $_POST["college"])));
		$_SESSION["principal"]["phone"] = mysqli_real_escape_string($cv,preg_replace('/[^0-9+]/', "", $_POST["phone"]));
		$_SESSION["principal"]["crsid"] = mysqli_real_escape_string($cv,strtolower(preg_replace('/[^A-Za-z0-9+]/', "", $_POST["crsid"])));
		$_SESSION["principal"]["barcode"] = mysqli_real_escape_string($cv,strtoupper(preg_replace('/[^A-Za-z+]/', "", $_POST["barcode"])));
	}
	
	foreach($_SESSION["principal"] as $key=>$value) {
		if($value == "") {
			//please go back and correct
			$errors .= ucfirst($key) . " is incomplete <br />";
		}
	}
	
	//TODO: Better validation.
	if(strlen($_SESSION["principal"]["phone"]) < 5 || strlen($_SESSION["principal"]["phone"]) > 12) {
		$errors .= "Phone number isn't in the correct format. <br />";
	}
	
	if(strlen($_SESSION["principal"]["barcode"]) != 5) {
		$errors .= "Your university ID barcode isn't in the correct format. <br />";
	}
	
	if($_SESSION["principal"]["gender"] != "Male" && $_SESSION["principal"]["gender"] != "Female") {
		$errors .= "Gender must be either Male or Female. <br />";
	}
	
	
	if(isset($errors)) {
		echo $errors;
		echo "please go back and correct your details. <br />";
		echo "<a href='personal_buy.php?step=1'>&larr; Go Back</a>";
		exit();
	}
	
	$q = mysqli_real_query($cv, "SELECT ticket_type_id,ticket_type, price FROM ticket_types WHERE available = 1");
	if($result = mysqli_use_result($cv)) {
		while(($row = mysqli_fetch_assoc($result)) != null) {
			$ticket_options .= "<option value=\"" . $row["ticket_type_id"] . "\">" . $row["ticket_type"]  . " - ". $row["price"] . "</option>";
		}
	}
	mysqli_free_result($result);
	mysqli_close($cv);
?>
	<script type="text/javascript">
		function stripslashes(str) { 
    		return str.replace(/\\/g, '');
		}
		
	
		
		function addTicket(i) {
			addTicket.count = ++addTicket.count || 1;
			numberOfDivsPresent = 0;
			$.each($("#additional_tickets").contents(), function(i, data) {
				numberOfDivsPresent++;
			});
			
			if(i >= 1) {
				addTicket.count = i;
			}
			if(numberOfDivsPresent < 9) {
				$("#additional_tickets").append('<div class="ticket" id="ticket_' + addTicket.count + '">');
				$("#ticket_" + addTicket.count).append('<label for="ticket_'  + addTicket.count + '_crsid_field">CRSID: </label><input type="text" name="ticket_'  + addTicket.count + '_crsid" id="ticket_'  + addTicket.count + '_crsid_field" /> ');
				$("#ticket_" + addTicket.count).append('<input type="button" value="Lookup CRSID" id="ticket_'  + addTicket.count + '_lookup" /><br />');
				$("#ticket_" + addTicket.count).append('<span id="ticket_' + addTicket.count + '_barcode_span"></span>');
				
				$("#ticket_"  + addTicket.count + "_lookup").bind("click", function(){ 
 					$.post("../ldap_ajax.php",{ crsid : $("#ticket_" + addTicket.count + "_crsid_field").val() }, function(json) {
 						$("#ticket_" + addTicket.count + "_first_name_field").val(json.first_name);
 						$("#ticket_" + addTicket.count + "_last_name_field").val(json.last_name);
 						$("#ticket_" + addTicket.count + "_title_field").val(json.title);
 					}, "json"); 
 					
 					$("#ticket_" + addTicket.count + "_barcode_span").html('<label for="ticket_'  + addTicket.count + '_barcode_field">Barcode*: </label><input type="text" name="ticket_'  + addTicket.count + '_barcode" id="ticket_'  + addTicket.count + '_barcode_field" /><br />');

 					
				});
				
				
				
				$("#ticket_" + addTicket.count).append('<label for="ticket_'+ addTicket.count + '_title_field">Title*: </label><select id="ticket_' + addTicket.count + '_title_field" name="ticket_' + addTicket.count + '_title"><option value="Mr">Mr</option><option value="Mrs">Mrs</option><option value="Miss">Miss</option><option value="Ms">Ms</option><option value="Dr">Dr</option><option value="Prof">Prof</option><option value="Sir">Sir</option></select><br />');
				$("#ticket_" + addTicket.count).append('<label for="ticket_' + addTicket.count + '_first_name_field">First Name*: </label><input type="text" name="ticket_'  + addTicket.count + '_first_name" id="ticket_'  + addTicket.count + '_first_name_field" /><br />');
				$("#ticket_" + addTicket.count).append('<label for="ticket_' + addTicket.count + '_last_name_field">Last Name*: </label><input type="text" name="ticket_'  + addTicket.count + '_last_name" id="ticket_'  + addTicket.count + '_last_name_field" /><br />');
				$("#ticket_" + addTicket.count).append('<label for="ticket_' + addTicket.count + '_gender_field">Gender*: </label><select id="ticket_' + addTicket.count + '_gender_field" name="ticket_' + addTicket.count + '_gender"><option value="Male">Male</option><option value="Female">Female</option></select><br />')
				
				$("#ticket_" + addTicket.count).append('<label for="ticket_' + addTicket.count + '_ticket_type_id">Ticket*: </label><select name="ticket_' + addTicket.count + '_ticket_type_id" id="ticket_' + addTicket.count + '_ticket_type_id_field"><?= $ticket_options ?></select><br />');
				$("#ticket_" + addTicket.count).append('<a href="javascript:removeTicket(' + addTicket.count + ')">Remove Ticket</a>');
				$("#ticket_" + addTicket.count).append('<br />');
				
			}
			else {
				alert("You may only order 9 additional tickets");
			}
		}
		
		function removeTicket(i) {
			$("#ticket_" + i).html("");
			$("#ticket_" + i).remove("");
		}
	
		$("document").ready(function() {
			$("#add_ticket").bind("click", addTicket);
			//restores session data to fields
			session_data = <?= json_encode($_SESSION) ?>;
			$.each(session_data.guests, function(i, data) {
				if(data != "undefined") {
					addTicket(i);
					$("#ticket_" + i + "_crsid_field").val(data.crsid);
					if(data.crsid != "undefined") {
						$("#ticket_" + addTicket.count + "_barcode_span").html('<label for="ticket_'  + addTicket.count + '_barcode_field">Barcode*: </label><input type="text" name="ticket_'  + addTicket.count + '_barcode" id="ticket_'  + addTicket.count + '_barcode_field" /><br />');
						$("#ticket_" + i + "_barcode_field").val(data.barcode);
					}
					$("#ticket_" + i + "_title_field").val(data.title);
					$("#ticket_" + i + "_first_name_field").val(stripslashes(data.first_name));
					$("#ticket_" + i + "_last_name_field").val(stripslashes(data.last_name));
					$("#ticket_" + i + "_gender_field").val(data.gender);
					$("#ticket_" + i + "_ticket_type_id_field").val(data.ticket_type_id);
					
				}
			});
		});
	</script>
	</head>
	<body>
	<h2>Tickets</h2>
	<form action="personal_buy.php?step=3" method="post">
	<h3>Your Ticket</h3>
	Name: <? echo stripslashes($_SESSION["principal"]["title"] . " " . $_SESSION["principal"]["first_name"] . " " . $_SESSION["principal"]["last_name"]); ?><br />
	CRSID: <?= $_SESSION["principal"]["crsid"] ?><br />
	Barcode: <?= $_SESSION["principal"]["barcode"] ?><br />
	Ticket*: <select name="principal_ticket_type">
			<?=	$ticket_options ?>
			</select><br /><br />
	
	<input type="button" id="add_ticket" value="Add New Ticket" /><br /><br />
	<div id="additional_tickets"></div><br />
	<input type="submit" value="Save &amp; Check Details &rarr;" />
	</form>		
	
	<?

}


if($_GET["step"] == 3) {
	//Order Summary
	$_SESSION["principal"]["ticket_type_id"] = preg_replace('/[^0-9+]/',"", $_POST["principal_ticket_type"]);
	$_SESSION["guests"] = array();
	
	foreach($_POST as $key=>$value) {
		if(preg_match('/ticket_([0-9])_(.*)/i',$key, $matches)) {
			$_SESSION["guests"][$matches[1]][$matches[2]] = $value;
		}
	}
	include_once "../database_connect.php";
	foreach($_SESSION["guests"] as $key=>$value) {
		$_SESSION["guests"][$key]["crsid"] = mysqli_real_escape_string($cv,strtolower(preg_replace('/[^A-Za-z0-9+]/', "", $value["crsid"])));
		$_SESSION["guests"][$key]["barcode"] = mysqli_real_escape_string($cv,strtoupper(preg_replace('/[^A-Za-z0-9+]/', "", $value["barcode"])));
		$_SESSION["guests"][$key]["title"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z+]/', "", $value["title"])));
		$_SESSION["guests"][$key]["first_name"] = mysqli_real_escape_string($cv, stripslashes(preg_replace('/[^A-Za-z\'\.\s+]/', "", $value["first_name"])));
		$_SESSION["guests"][$key]["last_name"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z\'\.\s+]/', "", $value["last_name"])));
		$_SESSION["guests"][$key]["gender"] = mysqli_real_escape_string($cv,stripslashes(preg_replace('/[^A-Za-z+]/', "", $value["gender"])));
		
		
		if($value["first_name"] == "") {
			$errors .= "A guest's first name is incomplete<br />";
		}
		
		if($value["last_name"] == "") {
			$errors .= "A guest's last name is incomplete<br />";
		}  
		
		if($value["crsid"] != "" && strlen($value["barcode"]) != 5) {
			$errors .= "A guest's university ID barcode isn't in the correct format. <br />";
		}
		if($value["gender"] != "Male" && $value["gender"] != "Female") {
		$errors .= "Gender must be either Male or Female. <br />";
		}
		
		
		
	}
	
	
	if(isset($errors)) {
		echo $errors;
		echo "please go back and correct your details. <br />";
		echo "<a href='personal_buy.php?step=2'>&larr; Go Back</a>";
		exit();
	}
	$price = 0;
	?>
	<h2>Check Application</h2>
	<p>Please check to make sure that all the following information is correct. </p>
	<h3>Applicant</h3>
	<a href="personal_buy.php?step=1">Edit applicant details...</a><br />
	Name: <?= stripslashes($_SESSION["principal"]["title"] . " " . $_SESSION["principal"]["first_name"] . " " . $_SESSION["principal"]["last_name"]) ?><br />
	Gender: <?= $_SESSION["principal"]["gender"]; ?><br />
	College: <?= stripslashes($_SESSION["principal"]["college"]); ?><br />
	Phone: <?= $_SESSION["principal"]["phone"]; ?><br />
	CRSID: <?= $_SESSION["principal"]["crsid"]; ?><br />
	Barcode: <?= $_SESSION["principal"]["barcode"]; ?><br />
	Ticket: <?
	include_once "../database_connect.php";
	$ticket = $_SESSION["principal"]["ticket_type_id"];
	$q = mysqli_real_query($cv, "SELECT ticket_type, price FROM ticket_types WHERE available = 1 AND ticket_type_id = '$ticket'");
	if($result = mysqli_use_result($cv)) {
		$row = mysqli_fetch_assoc($result);
		echo $row["ticket_type"] . " - " . "&#163;" . $row["price"];
		$price += $row["price"];	
	}
	mysqli_free_result($result);
	echo "<br />";
	
	if(!empty($_SESSION["guests"])) {
	?>
	<h3>Additional Tickets</h3>
	<a href="personal_buy.php?step=2">Edit ticket details...</a><br />
	<?
	}
	foreach($_SESSION["guests"] as $key=>$value) {
		?>
			Name: <?= stripslashes($value["title"] . " " . $value["first_name"] . " " . $value["last_name"]) ?><br />
			Gender: <?= $value["gender"]; ?><br />
			CRSID: <?= $value["crsid"]; ?><br />
			Barcode: <?= $value["barcode"]; ?><br />
			Ticket: <?
			include_once "../database_connect.php";
			$ticket = $value["ticket_type_id"];
			$q = mysqli_real_query($cv, "SELECT ticket_type, price FROM ticket_types WHERE available = 1 AND ticket_type_id = '$ticket'");
			if($result = mysqli_use_result($cv)) {
				$row = mysqli_fetch_assoc($result);
				echo $row["ticket_type"] . " - " . "&#163;" . $row["price"];
				$price += $row["price"];
			}
			mysqli_free_result($result);
		?>
		<br /><br />
		<?
	}
	?>
	
	
	<br />
	<b>Total Price: &#163;<?
	$_SESSION["price"] = sprintf("%01.2f", $price);
	echo $_SESSION["price"] . "</b><br />";
		
	
	?>
	<p>By confirming this selection you are committing to buying these tickets. You will be given a choice of payment options on the next screen.</p>
	<form action="personal_buy.php?step=4" method="post">
	<input type="submit" value="Confirm &rarr;" />
	</form>
	<?
	mysqli_close($cv);

}

if($_GET["step"] == 4) {
	$total = $_SESSION["price"];
	?>
	<h2>Payment</h2>
	<h3>Your Order</h3>
	<?
	$order[$_SESSION["principal"]["ticket_type_id"]] = 1;
	
	foreach($_SESSION["guests"] as $key=>$value){
		$order[$value["ticket_type_id"]]++;
	}
	
	include "../database_connect.php";
	$tickets = array();
	$q = mysqli_real_query($cv, "SELECT ticket_type_id,ticket_type, price FROM ticket_types WHERE available = 1");
	if($result = mysqli_use_result($cv)) {
		while(($row = mysqli_fetch_assoc($result)) != null) {
			$tickets[$row["ticket_type_id"]] = array("ticket_type" => $row["ticket_type"], "price" => $row["price"]);
		}
	}
	mysqli_free_result($result);


	foreach($order as $key=>$value) {
		echo $value . " x " . $tickets[$key]["ticket_type"] . " @ &#163;" . $tickets[$key]["price"] . " each = &#163;" . sprintf("%01.2f", $value * $tickets[$key]["price"]) . "<br />";
	}
	
	echo "<br />";
	if(!is_numeric($_SESSION["request_id"])) {
		//Save information to database
		
		//check to see if we have room?
		include_once "../maximums.php";
		$q = mysqli_real_query($cv, "SELECT ticket_type_id,COUNT(1) FROM tickets GROUP BY ticket_type_id");
		if($result = mysqli_use_result($cv)) {
			while(($row = mysqli_fetch_assoc($result)) != null) {
				$ticket_counts[$row["ticket_type_id"]] = $row["COUNT(1)"];
			}
		}
		mysqli_free_result($result);
		
		$enough_room = true;
		foreach($order as $key=>$value) {
			if($ticket_counts[$key] >= $maximums[$key]) {
				$enough_room = false;
				$errors .= "Sorry, we don't have any " . $tickets[$key]["ticket_type"] . " tickets left<br />";
			}
		}
		if(!$enough_room) {
			echo $errors;
			exit();
		}
		
		
		//create request
		mysqli_real_query($cv, "INSERT INTO requests (status, total_cost, created_at) VALUES('created', '$total', NOW());");
		$request_id = mysqli_insert_id($cv);
		$_SESSION["request_id"] = $request_id;
		
		//create principal person
		mysqli_real_query($cv, "INSERT INTO people (request_id, title, first_name, last_name, crsid, uni_barcode, email, college, phone, gender, created_at) VALUES(
		'$request_id',
		'". $_SESSION["principal"]["title"] . "',
		'". $_SESSION["principal"]["first_name"] . "',
		'". $_SESSION["principal"]["last_name"] . "',
		'". $_SESSION["principal"]["crsid"] . "',
		'". $_SESSION["principal"]["barcode"] . "',
		'". $_SESSION["principal"]["crsid"] . "@cam.ac.uk',
		'". $_SESSION["principal"]["college"] . "',
		'". $_SESSION["principal"]["phone"] . "',
		'". $_SESSION["principal"]["gender"] . "',
		NOW()
		);");
		if(mysqli_errno($cv) == 1062) {
		echo $_SESSION["principal"]["title"] . " " . $_SESSION["principal"]["first_name"] . " " . $_SESSION["principal"]["last_name"] . " seems to already be going to the ball!<br />";
		echo "Please contact mayball-tickets@jesus.cam.ac.uk if you think this message is in error.<br />";
		exit();
		}
		
		$principal_id = mysqli_insert_id($cv);
		$_SESSION["principal"]["id"] = $principal_id;
		
		include_once "../hash_codes.php";
		$hash_code = ticket_hash_code($principal_id);
		//create principal ticket
		mysqli_real_query($cv, "INSERT INTO tickets (ticket_type_id, hash_code, price, person_id, created_at) VALUE(
		'". $_SESSION["principal"]["ticket_type_id"] . "',
		'". $hash_code . "',
		'". $tickets[$_SESSION["principal"]["ticket_type_id"]]["price"] . "',
		'$principal_id',
		NOW()
		)");
		
		
		//update request to have principal_id
		mysqli_real_query($cv,"UPDATE requests SET principal_id='$principal_id' WHERE request_id='$request_id';");
		echo mysqli_error($cv);
		
		
		foreach($_SESSION["guests"] as $key=>$value) {
			//create each guest person
			mysqli_real_query($cv, "INSERT INTO people (request_id, title, first_name, last_name, crsid, uni_barcode, gender, created_at,no_crsid) VALUE(
			'$request_id',
			'" . $value["title"] . "',
			'" . $value["first_name"] . "',
			'" . $value["last_name"] . "',
			'" . $value["crsid"] . "',
			'" . $value["barcode"] . "',
			'" . $value["gender"] . "',
			NOW(),
			'" . (($value["crsid"] === "") ? 1 : 0) . "'
			);");
			if(mysqli_errno($cv) == 1062) {
				echo $value["title"] . " " . $value["first_name"] . " " . $value["last_name"] . " seems to already be going to the ball!<br />";
				echo "Please contact mayball-tickets@jesus.cam.ac.uk if you think this message is in error.<br />";
				exit();
			}
			$guest_id = mysqli_insert_id($cv);
			$_SESSION["guests"][$key]["id"] = $guest_id;
			
			$hash_code = ticket_hash_code($guest_id);
			//create each guest ticket
			mysqli_real_query($cv, "INSERT INTO tickets (ticket_type_id, hash_code, price, person_id, created_at) VALUE(
			'". $value["ticket_type_id"] . "',
			'". $hash_code . "',
			'". $tickets[$value["ticket_type_id"]]["price"] . "',
			'$guest_id',
			NOW()
			)");
			mysqli_close($cv);
		}

	}
	
	
	
	?>
	<b>Total: &#163;<?= $total ?></b> (&#163;<?= $paypal_total = sprintf("%01.2f",ceil((($total + 0.2)/0.966)*100)/100) ?> with Paypal)<br /><br />
	<form action="personal_buy.php?step=cheque" method="post">
	<input type="submit" value="Pay via Cheque &rarr;" /> Payment via cheque carries <b>no surcharge</b>. 
	</form>
	<form action="personal_buy.php?step=alternative_payment" method="post">
	<input type="submit" value="Pay via an alternative method &rarr;" /> Payment via BACS, cash, or some other method. 
	</form>

	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	<input type="hidden" name="cmd" value="_cart" />
	<input type="hidden" name="upload" value="1" /> 
	<input type="hidden" name="business" value="mayball-treasurer@jesus.cam.ac.uk" /> 
	<input type="hidden" name="item_name_1" value="Jesus May Ball 2009 ticket(s)" /> 
	<input type="hidden" name="amount_1" value="<?= sprintf("%01.2f", $paypal_total) ?>" />
	<input TYPE="hidden" NAME="return" value="http://jesusmayball.com/tickets/raven/personal_buy.php?step=paypal" />
	<input TYPE="hidden" NAME="notify-url" value="http://jesusmayball.com/tickets/paypal_ipn.php" />
	
	<input type="hidden" name="currency_code" value="GBP" />
	<input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="">
	<img alt="" border="0" src="https://www.paypal.com/en_GB/i/scr/pixel.gif" width="1" height="1">
	</form>
<?
	
}

if($_GET["step"] == "paypal") {
?>

Thank you for paying via paypal.
 <form action="personal_buy.php?step=finalise" method="post">
 <input type="hidden" name="payment_method" value="paypal" />
 <input type="submit" value="Complete application" />
 </form>
<?
}

if($_GET["step"] == "cheque") {
	?>
	<h2>Payment via Cheque</h2>
	<p>Please write a cheque for &#163;<?= $_SESSION["price"] ?> out to "Jesus May Ball Committee" with <?
	include_once("../database_connect.php");
	mysqli_real_query($cv, "INSERT INTO cheques (amount, request_id, created_at, status) VALUES (
	'" . $_SESSION["price"] . "',
	'" . $_SESSION["request_id"] . "',
	NOW(),
	'unpaid'
	);") or mysqli_real_query($cv, "SELECT * FROM cheques WHERE request_id='" .  $_SESSION["request_id"]. "';");
	if($result = mysqli_use_result($cv)) {
		$cheque = mysqli_fetch_assoc($result);
		$cheque_id = $cheque["cheque_id"];
		echo $hash_code = $cheque["hash_code"];
	}
	else {
		$cheque_id = mysqli_insert_id($cv);
		include_once("../hash_codes.php");
		echo $hash_code = cheque_hash_code($cheque_id);
		mysqli_real_query($cv, "UPDATE cheques SET hash_code = '$hash_code' WHERE cheque_id = '$cheque_id';");
	}
	 ?> written on the back along with the name of principal applicant, <?= $_SESSION["principal"]["title"] . " " . $_SESSION["principal"]["first_name"] . " " . $_SESSION["principal"]["last_name"] ?>.</p>
	 Front:<br />
	 <img src="../cheque_image.php?type=front&total=<?= $_SESSION["price"] ?>" alt="cheque front" /><br />
	 Back:<br />
	 <img src="../cheque_image.php?type=back&cheque_no=<?= $hash_code ?>&name=<?= $_SESSION["principal"]["title"] . " " . $_SESSION["principal"]["first_name"] . " " . $_SESSION["principal"]["last_name"] ?>" alt="cheque front" /><br />
	 <p>Jesuans can drop their cheque of in the bar during the publicised times. Otherwise there will be a folder kept in Jesus College Porters' Lodge to deposit your cheque personally or to receive cheques sent via CUSU-MS.  </p>
	 <form action="personal_buy.php?step=finalise" method="post">
	 <input type="hidden" name="payment_method" value="cheque" />
	 <input type="submit" value="Complete application" />
	 </form>
	<?
}

if($_GET["step"] == "finalise") {
	//create receipt
	$body = "email message";
	$app_id = 1;
	
	//send via email to principal.
	$headers .= "From: Jesus May Ball 2009<mayball-tickets@jesus.cam.ac.uk>\r\n" . "X-Mailer: php";
	$subject = "Jesus May Ball 2009 - Confirmation of Ticket Order";
	mail("rad55@cam.ac.uk", $subject, $body, $headers);
	
	//save in receipts folder.
	file_put_contents("../receipts/order_" . $app_id . "_confirm.txt", $body);
}

?>
</body>
</html>