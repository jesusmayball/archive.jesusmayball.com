<?php

function editTicket() {

?>
<form>
<input type="text" value="" /><br />
<input type="text" value="" />
<input type="text" value="" />
<input type="text" value="" /><br />

</form>
<?

}

?>