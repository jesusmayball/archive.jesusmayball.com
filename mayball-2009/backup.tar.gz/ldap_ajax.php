<?php
include "ldap_client.php";

$id = getLookupInfo($_POST["crsid"]);

echo json_encode($id);

?>