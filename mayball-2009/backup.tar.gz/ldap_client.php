<?php

function getLookupInfo($uid) {
	$ds=ldap_connect("ldap.lookup.cam.ac.uk");  // must be a valid LDAP server!

	if ($ds) {
		$r = ldap_bind($ds);
		$user_lookup = addslashes($uid);
		$sr = ldap_search($ds, "ou=people, o=University Of Cambridge,dc=cam, dc=ac, dc=uk", "uid=$user_lookup");  
		$info = ldap_get_entries($ds, $sr);
		ldap_close($ds);
		
		$college = $info[0]["ou"];
		
		if($college["count"] > 1) {
			for($i = 0; $i < $college["count"]; $i++) {
				if(strpos($college[$i], "College") !== false) {
					$college = explode(" -",$college[$i]);
					$college = $college[0];
				}
			}
		}
		else {
			$college = explode(" -",$college[0]);
			$college = $college[0];
		}
		$last_name = $info[0]["sn"][0];
		$name = explode(" ", $info[0]["cn"][0]);
		if(preg_match('/(Dr|Prof\.|Sir|Lady|Rev\.)/i', $name[0])) {
			$first_name = $name[1];
			$title = explode(".", $name[0]);
			$title = $title[0];
		}
		else {
			$first_name = $name[0];
			$title = "Mr";
		}
		
		
		$array = array("title" => $title,"first_name" => $first_name, "last_name" => $last_name, "college" => $college);
		return $array;

	} else {
		return "unable to connect to ldap server";
	}
}

?>