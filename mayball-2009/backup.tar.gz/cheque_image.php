<?php




function int_to_words($x)
{
	$nwords = array(	"zero", "one", "two", "three", "four", "five", "six", "seven",
					"eight", "nine", "ten", "eleven", "twelve", "thirteen",
					"fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
					"nineteen", "twenty", 30 => "thirty", 40 => "forty",
					50 => "fifty", 60 => "sixty", 70 => "seventy", 80 => "eighty",
					90 => "ninety" );
	
	if(!is_numeric($x))
	{
		$w = '#';
	}else if(fmod($x, 1) != 0)
	{
		$w = '#';
	}else{
		if($x < 0)
		{
			$w = 'minus ';
			$x = -$x;
		}else{
			$w = '';
		}
		if($x < 21)
		{
			$w .= $nwords[$x];
		}else if($x < 100)
		{
			$w .= $nwords[10 * floor($x/10)];
			$r = fmod($x, 10);
			if($r > 0)
			{
				$w .= '-'. $nwords[$r];
			}
		} else if($x < 1000)
		{
			$w .= $nwords[floor($x/100)] .' hundred';
			$r = fmod($x, 100);
			if($r > 0)
			{
				$w .= ' and '. int_to_words($r);
			}
		} else if($x < 1000000)
		{
			$w .= int_to_words(floor($x/1000)) .' thousand';
			$r = fmod($x, 1000);
			if($r > 0)
			{
				$w .= ' ';
				if($r < 100)
				{
					$w .= 'and ';
				}
				$w .= int_to_words($r);
			}
		} else {
			$w .= int_to_words(floor($x/1000000)) .' million';
			$r = fmod($x, 1000000);
			if($r > 0)
			{
				$w .= ' ';
				if($r < 100)
				{
					$word .= 'and ';
				}
				$w .= int_to_words($r);
			}
		}
	}
	return $w;
}

define("ALIGN_LEFT", "left");
define("ALIGN_CENTER", "center");
define("ALIGN_RIGHT", "right");

function imagettftextbox(&$image, $size, $angle, $left, $top, $color, $font, $text, $max_width)
{
        $text_lines = explode("\n", $text); // Supports manual line breaks!
        
        $lines = array();
        $line_widths = array();
        
        $largest_line_height = 20;
        
        foreach($text_lines as $block)
        {
            $current_line = ''; // Reset current line
            
            $words = explode(' ', $block); // Split the text into an array of single words
            
            $first_word = TRUE;
            
            $last_width = 0;
            
            for($i = 0; $i < count($words); $i++)
            {
                $item = $words[$i];
                $dimensions = imagettfbbox($size, $angle, $font, $current_line . ($first_word ? '' : ' ') . $item);
                $line_width = $dimensions[2] - $dimensions[0];
                $line_height = $dimensions[1] - $dimensions[7];
                
                //if($line_height > $largest_line_height) $largest_line_height = $line_height;
                
                if($line_width > $max_width && !$first_word)
                {
                    $lines[] = $current_line;
                    
                    $line_widths[] = $last_width ? $last_width : $line_width;
                    
                    /*if($i == count($words))
                    {
                        continue;
                    }*/
                    
                    $current_line = $item;
                }
                else
                {
                    $current_line .= ($first_word ? '' : ' ') . $item;
                }
                
                if($i == count($words) - 1)
                {
                    $lines[] = $current_line;
                    
                    $line_widths[] = $line_width;
                }
                
                $last_width = $line_width;
                    
                $first_word = FALSE;
            }
            
            if($current_line)
            {
                $current_line = $item;
            }
        }
        
        $i = 0;
        foreach($lines as $line)
        {
            if($align == ALIGN_CENTER)
            {
                $left_offset = ($max_width - $line_widths[$i]) / 2;
            }
            elseif($align == ALIGN_RIGHT)
            {
                $left_offset = ($max_width - $line_widths[$i]);
            }
            imagettftext($image, $size, $angle, $left + $left_offset, $top + $largest_line_height + ($largest_line_height * $i), $color, $font, $line);
            $i++;
        }
        
        return $largest_line_height * count($lines);
}


putenv('GDFONTPATH=' . realpath('.'));
$font = 'Jerry_handwriting';

header('Content-type: image/png');

if($_GET["type"] == "front") {
	$im = imagecreatefrompng("cheque_front.png");
	$black = imagecolorallocate($im, 0, 0, 0);
	imagettftext($im, 18, 0, 400, 119,	 $black, $font, sprintf("%01.2f", $_GET["total"]));
	imagettftextbox($im, 16, 0, 42, 95, $black, $font, int_to_words($_GET["total"]) . " pounds only", 320);
}
else if($_GET["type"] == "back") {
	$im = imagecreatefrompng("cheque_back.png");
	$black = imagecolorallocate($im, 0, 0, 0);
	imagettftext($im, 32, 0, 50, 100, $black, $font, urldecode($_GET["name"]));
	imagettftext($im, 32, 0, 50, 150, $black, $font, $_GET["cheque_no"]);
	
}

imagepng($im);
imagedestroy($im);

?>