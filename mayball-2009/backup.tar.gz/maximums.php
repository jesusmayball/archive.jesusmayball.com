<?php

$maximum_standard = 1250;
$maximum_priority = 300;
$maximum_dining = 100;

$maximums = array(1 => $maximum_standard, 2 => $maximum_priority, 3 => $maximum_dining);

?>