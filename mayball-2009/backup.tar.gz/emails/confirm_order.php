To <?= $principal ?>,

Your application ID is <?= $app_id ?>
Thank you for ordering tickets to Jesus May Ball 2009. Here is a summary of your order:


<!-- ORDER SUMMARY -->


We are awaiting payment of <?= $price ?> via <?= $payment_method ?>.
<? if($payment_method == "cheque") {
	?>
	Please write your name, <?= $principal ?>, and this code <?= $cheque_id ?> on the reverse of the cheque. Jesuans can drop their cheque of in the bar during the publicised times. Otherwise there will be a folder kept in Jesus College Porters' Lodge to deposit your cheque personally or to receive cheques sent via CUSU-MS.
	<?
}
?>

If you have any queries, please contact mayball-tickets@jesus.cam.ac.uk